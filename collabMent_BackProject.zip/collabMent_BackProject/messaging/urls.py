from django.urls import path
# from .views import MessageAPIView

urlpatterns = [
    # path('messages/<int:sender_id>/<int:receiver_id>/', MessageAPIView.as_view(), name='messages'),
]
